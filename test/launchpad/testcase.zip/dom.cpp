#include "base/types/shared_ptr.h"

#include <stdio.h>
#include <sstream>

#include "base/impl/dictionary/dictionary_by_attribute_name.h"
#include "base/impl/resource/directory_resource.h"
#include "base/impl/resource/dom_resource.h"
#include "base/util/documents.h"
#include "base/util/strings.h"
#include "base/types/weak_ptr.h"

#include "test/base/test_case.h"

#include "platform/platform.h"

namespace ark {
namespace unittest {

class DOMTestCase : public TestCase {
public:
    virtual int launch() {
        sp<Resource<document>> docLoader = Platform::getXMLResource(".");
        document doc = docLoader->load("application.xml");
        if(!doc) {
            printf("application.xml not found!\n");
            return -1;
        }

        std::stringstream sb;
        Documents::print(doc, sb);

        for(const document& node : doc->children("frame"))
            Documents::print(node, sb);

        sp<Dictionary<document>> dict1 = sp<DictionaryByAttributeName>::make(doc, "id");
        sp<Dictionary<document>> dict2 = sp<DictionaryByAttributeName>::make(doc, "id", "expirable");

        if(!dict1->get("script", nullptr))
            return 1;
        if(!dict1->get("t4", nullptr))
            return 2;

        if(!dict2->get("e1", nullptr))
            return 3;
        if(!dict2->get("e004", nullptr))
            return 4;
        if(dict2->get("t4", nullptr))
            return 5;

        return 0;
    }

};

}
}


ark::unittest::TestCase* dom_create() {
    return new ark::unittest::DOMTestCase();
}
