#include "test/base/test_case.h"

#include "base/ark.h"
#include "base/inf/dictionary.h"

#include "renderer/base/gl_shader.h"

namespace ark {
namespace unittest {

class GLProgramsTestCase : public TestCase {
public:
    virtual int launch() {
        const auto& stringtable = Ark::instance().getStringTable("shaders");
        GLShader shader(stringtable->get("vertex", nullptr), stringtable->get("fragment_vcolor", nullptr));
        return 0;
    }
};

}
}

ark::unittest::TestCase* gl_programs_create() {
    return new ark::unittest::GLProgramsTestCase();
}
