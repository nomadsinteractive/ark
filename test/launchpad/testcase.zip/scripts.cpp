
#include "test/base/test_case.h"

#include "base/ark.h"
#include "base/bean_factory.h"
#include "base/impl/dictionary/dictionary_by_attribute_name.h"
#include "base/impl/dictionary/scope_impl.h"
#include "base/inf/resource.h"
#include "base/inf/readable.h"
#include "base/plugin/script_interpreter.h"
#include "base/types/shared_ptr.h"
#include "base/util/strings.h"

#include "platform/platform.h"

namespace ark {
namespace unittest {

class ScriptsTestCase : public TestCase {
public:
    virtual int launch() override {
        sp<Resource<document>> docLoader = Platform::getXMLResource(".");
        document doc = docLoader->load("application.xml");
        if(!doc) {
            printf("application.xml not found!\n");
            return -1;
        }
        sp<Dictionary<document>> byId = sp<Dictionary<document>>::adopt(new DictionaryByAttributeName(doc, "id"));

        Ark& ark = Ark::instance();
        Ark::instance().loadPlugin("ark-plugin-python");

        sp<BeanFactory> beanFactory = ark.createBeanFactory(byId);

        sp<ScriptInterpreter> scriptInterpreter = beanFactory->build<ScriptInterpreter>("@script");
        if(!scriptInterpreter) {
            puts("No script interpreter installed");
            return -1;
        }
        sp<Readable> readable = Platform::getAssetResource(".")->load("hello.py");
        if(!readable) {
            puts("Cannot find hello.py");
            return -1;
        }
        sp<ScopeImpl> vars = sp<ScopeImpl>::adopt(new ScopeImpl());
        scriptInterpreter->run(Strings::loadFromReadable(readable), vars);
        return 0;
    }
};

}
}

ark::unittest::TestCase* scripts_create()
{
    return new ark::unittest::ScriptsTestCase();
}
