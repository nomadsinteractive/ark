#include "test/base/test_case.h"

#include <stdint.h>
#include <chrono>
#include <thread>

#include "base/inf/runnable.h"
#include "base/impl/expirable/expirable_impl.h"
#include "base/impl/message_loop/message_loop_default.h"
#include "base/types/shared_ptr.h"

#include "app/base/thread.h"
#include "app/base/message_loop_thread.h"
#include "app/base/thread_executor.h"

#include "platform/platform.h"



namespace ark {
namespace unittest {

class RunnableImpl : public Runnable {
public:
    RunnableImpl(const std::string& tag)
        : _tick(0), _tag(tag) {
    }

    virtual void run() {
        printf("%s = %d\n", _tag.c_str(), _tick ++);
    }

    uint32_t tick() const {
        return _tick;
    }

private:
    uint32_t _tick;
    std::string _tag;
};

class Sleeper : public Runnable {
public:
    Sleeper(const std::string& tag, int32_t seconds)
        : _tag(tag), _seconds(seconds) {
    }

    virtual void run() override {
        std::this_thread::sleep_for(std::chrono::seconds(_seconds));
        printf("[%s] done after %d seconds\n", _tag.c_str(), _seconds);
    }

private:
    std::string _tag;
    int32_t _seconds;

};

class MessageLoopTestCase : public TestCase {
public:
    virtual int launch() override {
        return 0;
        sp<MessageLoopThread> messageLoopThread = sp<MessageLoopThread>::make(sp<MessageLoopDefault>::make(Platform::getSystemTickVariable()));
        messageLoopThread->start();
        sp<RunnableImpl> task = sp<RunnableImpl>::make("a");
        sp<RunnableImpl> task1 = sp<RunnableImpl>::make("b");
        sp<RunnableImpl> task2 = sp<RunnableImpl>::make("c");
        sp<ExpirableImpl> expirable = sp<ExpirableImpl>::make();
        messageLoopThread->post(task, 0.2f);
        messageLoopThread->schedule(task1, 0.3f);
        messageLoopThread->schedule(task2.absorb(expirable), 0.3f);
        expirable->expire();
        std::this_thread::sleep_for(std::chrono::seconds(1));
        messageLoopThread->terminate();
        messageLoopThread->thread()->join();

        ThreadExecutor threadExecutor;
        threadExecutor.post(sp<Sleeper>::make("Alpha", 2));
        threadExecutor.post(sp<Sleeper>::make("Beta", 5));
        std::this_thread::sleep_for(std::chrono::seconds(3));
        threadExecutor.post(sp<Sleeper>::make("Gamma", 1));
        std::this_thread::sleep_for(std::chrono::seconds(5));

        return task->tick() == 1 && task1->tick() == 4 && task2->tick() == 1 ? 0 : -1;
    }
};

}
}

ark::unittest::TestCase* message_loops_create() {
    return new ark::unittest::MessageLoopTestCase();
}
