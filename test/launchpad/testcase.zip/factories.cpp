#include "test/base/test_case.h"

#include <chrono>
#include <thread>

#include "base/ark.h"
#include "base/bean_factory.h"
#include "base/inf/expirable.h"
#include "base/inf/resource.h"
#include "base/inf/variable.h"
#include "base/impl/dictionary/dictionary_by_attribute_name.h"
#include "base/impl/dictionary/scope_impl.h"
#include "base/impl/variable/variable_impl.h"
#include "base/util/clock.h"

#include "graphics/inf/vertex.h"
#include "graphics/base/transform.h"

#include "platform/platform.h"


namespace ark {
namespace unittest {

class FactoriesCase : public TestCase {
public:
    virtual int launch() {
        sp<Resource<document>> docLoader = Platform::getXMLResource(".");
        document doc = docLoader->load("application.xml");
        if(!doc) {
            printf("application.xml not found!\n");
            return -1;
        }
        sp<Dictionary<document>> byId = sp<Dictionary<document>>::adopt(new DictionaryByAttributeName(doc, "id"));

        Ark& ark = Ark::instance();
        ark.put<Clock>(sp<Clock>::adopt(new Clock(Platform::getSystemTickVariable())));

        sp<BeanFactory> beanFactory = ark.createBeanFactory(byId);

        sp<Expirable> e1 = beanFactory->load<Expirable>("e1");
        sp<Expirable> e2 = beanFactory->load<Expirable>("e2");

        if(!e1 || !e2 || e1->isExpired() || e2->isExpired())
            return 1;

        if(e2.is<Expirable::Mutable>())
            e2.as<Expirable::Mutable>()->expire();
        else
            return 2;

        if(!e2->isExpired())
            return 3;

        std::this_thread::sleep_for(std::chrono::seconds(3));

        if(!e1->isExpired())
            return 4;

        sp<Numeric> g1 = beanFactory->build<Numeric>("25.0");
        if(!g1 || g1->obtain() != 25.0f)
            return 5;

        sp<Numeric> g2 = beanFactory->load<Numeric>("linear");
        if(!g2 || g2->obtain() != 100.0f)
            return 6;
        ark.put<Variable<uint64_t>>(Platform::getSystemTickVariable());
        sp<Numeric> g3 = beanFactory->load<Numeric>("acceleration");
        if(!g3 || g3->obtain() != 120.0f)
            return 7;

        sp<Numeric> g4 = beanFactory->load<Numeric>("g4");
        if(!g4 || g4->obtain() != 0)
            return 8;

        sp<Numeric> g5 = beanFactory->load<Numeric>("g5");
        if(!g5 || g5->obtain() != 1.0f)
            return 9;

        sp<Numeric> g6 = beanFactory->load<Numeric>("g6");
        if(!g6 || g6->obtain() != 6.0f)
            return 10;

        sp<ScopeImpl> arguments = sp<ScopeImpl>::make();
        arguments->put<Numeric>("$t", sp<VariableImpl<float>>::make(12.0f));
        sp<Numeric> g7 = beanFactory->load<Numeric>("g7", arguments);
        if(!g7 || g7->obtain() != 13.0f)
            return 11;

        sp<Vertex> vertex = beanFactory->load<Vertex>("vertex");
        if(!vertex || vertex->x() != 100.0f || vertex->y() != 120.0f)
            return -11;

        Class<Vec2> clazz = Class<Vec2>::instance();
        if(!clazz)
            return 12;

        sp<Vertex> v1 = beanFactory->load<Vertex>("v1");
        if(!v1 || v1->x() != 20 || v1->y() != 30)
            return 13;

        sp<Vertex> v2 = beanFactory->load<Vertex>("v2");
        if(!v2 || v2->x() != 100 || v2->y() != 30)
            return 14;

        sp<Vertex> v3 = beanFactory->load<Vertex>("v3");
        if(!v3 || v3->x() != 0 || v3->y() != 120)
            return 15;

        sp<Vertex> v4 = beanFactory->load<Vertex>("v4");
        if(!v4 || v4->x() != 150 || v4->y() != 170)
            return 16;

        sp<Transform> t1 = beanFactory->load<Transform>("t1");
        if(!t1 || t1->pivot()->x() != 20.0f || t1->pivot()->y() != 30.0f)
            return 17;

        sp<Transform> t2 = beanFactory->load<Transform>("t2");
        if(!t2 || t2->translation()->x() != 20.0f || t2->translation()->y() != 30.0f)
            return 18;

        sp<Transform> t3 = beanFactory->load<Transform>("t3");
        if(!t3 || t3->scale()->x() != 2.0f || t3->scale()->y() != 2.0f)
            return 19;

        sp<Transform> t4 = beanFactory->load<Transform>("t4");
        if(!t4 || t4->rotate() != 1.0f)
            return 20;

        sp<Expirable> e003 = beanFactory->load<Expirable>("e004");
        sp<Expirable> e003Copy = beanFactory->load<Expirable>("e004");
        if(e003 != e003Copy)
            return 21;

        return 0;
    }
};

}
}


ark::unittest::TestCase* factories_create() {
    return new ark::unittest::FactoriesCase();
}
