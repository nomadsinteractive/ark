#include "test/base/test_case.h"

namespace ark {
namespace unittest {

class ResourcesTestCase : public TestCase {
public:
    virtual int launch() {
        return 0;
    }
};

}
}


ark::unittest::TestCase* resources_create() {
    return new ark::unittest::ResourcesTestCase();
}
