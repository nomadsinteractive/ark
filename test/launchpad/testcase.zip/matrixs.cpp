#include <glm/mat4x4.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "test/base/test_case.h"

namespace ark {
namespace unittest {

class MatrixsCase : public TestCase {
public:
    virtual int launch() {
        float aaa[16];
        glm::mat4 bbb = glm::make_mat4(aaa);
        glm::mat4 projection = glm::ortho(0.0f, 540.0f, 960.0f, 0.0f, 0.0f, 5.0f);
        const float* ptr = glm::value_ptr(projection);
        return ptr == nullptr;
    }
};

}
}


ark::unittest::TestCase* matrixs_create() {
    return new ark::unittest::MatrixsCase();
}
