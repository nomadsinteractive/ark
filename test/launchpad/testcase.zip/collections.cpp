#include "base/types/shared_ptr.h"

#include <iostream>

#include <stdint.h>

#include "base/collection/expirable_item_list.h"
#include "base/concurrent/lock_free_stack.h"
#include "base/impl/expirable/expirable_impl.h"

#include "test/base/test_case.h"

namespace ark {
namespace unittest {

class CollectionsTestCase : public TestCase {
public:
    virtual int launch() override {
        sp<ExpirableImpl> expirable = sp<ExpirableImpl>::adopt(new ExpirableImpl());
        sp<Visibility> visibility = sp<Visibility>::make();
        ExpirableItemList<uint32_t> expirableList;

        for(uint32_t i = 0; i < 10; i++)
        {
            sp<uint32_t> ptr = sp<uint32_t>::adopt((new uint32_t(i)));
            if(i % 4 == 1)
                ptr.absorb<ExpirableImpl>(expirable);
            else if(i % 4 == 2)
                ptr.absorb<Visibility>(visibility);
            expirableList.push_back(ptr);
        }
        expirable->expire();

        uint32_t sum = 0;
        for(const sp<uint32_t>& i : expirableList)
            sum += *i.get();
        if(sum != 30)
            return 1;

        auto locked1 = expirableList.lock();
        visibility->hide();
        if(locked1.size() != 7)
            return 2;
        for(const sp<uint32_t>& i : locked1)
            sum += *i.get();
        if(sum != 60)
            return 3;

        auto locked2 = expirableList.lock();
        if(locked2.size() != 5)
            return 4;
        for(const sp<uint32_t>& i : locked1)
            sum += *i.get();
        if(sum != 82)
            return 5;

        visibility->display();
        auto locked3 = expirableList.lock();
        if(locked3.size() != 7)
            return 6;
        for(const sp<uint32_t>& i : locked3)
            sum += *i.get();
        if(sum != 112)
            return 7;

        LockFreeStack<uint32_t> slist;
        slist.push_front(10);
        slist.push_front(20);

        for(uint32_t i : slist)
            std::cout << i << std::endl;

        return 0;
    }
};

}
}


ark::unittest::TestCase* collections_create() {
    return new ark::unittest::CollectionsTestCase();
}
