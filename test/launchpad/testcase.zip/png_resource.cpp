#include "base/types/shared_ptr.h"

#include "base/impl/resource/directory_resource.h"

#include "graphics/impl/resource/png_resource.h"
#include "graphics/base/bitmap.h"

#include "test/base/test_case.h"

#include "platform/platform.h"



namespace ark {
namespace unittest {

class PNGResourceTestCase : public TestCase {
public:
    virtual int launch() {
        sp<Resource<bitmap>> pngLoader = sp<Resource<bitmap>>::adopt(new PNGResource(Platform::getImageResource()));
        bitmap s001 = pngLoader->load("s001.png");
        if(!s001) {
            printf("s001.png not found!\n");
            return -1;
        }
        if(s001->width() != 256)
            return -1;
        if(s001->height() != 256)
            return -1;
        return 0;
    }
};

}
}


ark::unittest::TestCase* png_resource_create() {
    return new ark::unittest::PNGResourceTestCase();
}
