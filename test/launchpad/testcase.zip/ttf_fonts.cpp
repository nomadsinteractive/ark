#include <stdio.h>
#include <string.h>
#include <math.h>

#include <ft2build.h>
#include FT_FREETYPE_H

#include "base/inf/readable.h"
#include "base/inf/resource.h"
#include "base/types/null.h"
#include "base/util/strings.h"

#include "graphics/base/bitmap.h"

#include "renderer/util/freetypes.h"
#include "renderer/util/gl_debug.h"
#include "renderer/util/freetypes.h"

#include "renderer/gles20/impl/alphabet/ttf_texture_alphabet.h"

#include "platform/platform.h"

#include "test/base/test_case.h"


#define WIDTH   640
#define HEIGHT  480


using namespace ark;

/* origin is the upper left corner */
op<Bitmap> image(new Bitmap(WIDTH, HEIGHT, WIDTH, 1));


/* Replace this function with something useful. */

void
draw_bitmap(FT_Bitmap*  bitmap,
            FT_Int      x,
            FT_Int      y)
{
    FreeTypes::drawBitmap(image.get(), bitmap, x, y);
}

int loadfonts(int argc, const char**  argv)
{
    FT_Face       face;

    FT_GlyphSlot  slot;
    FT_Vector     pen;                    /* untransformed origin  */
    FT_Error      error;

    const char*         filename;
    const char*         text;

    int           n, num_chars;


    if(argc != 3)
    {
        fprintf(stderr, "usage: %s font sample-text\n", argv[0]);
        exit(1);
    }

    memset(image->bytes(), 0, image->rowBytes() * image->height());

    filename      = argv[1];                           /* first argument     */
    text          = argv[2];                           /* second argument    */
    num_chars     = strlen(text);

    const sp<Readable> fontResource = Platform::getFontResource()->load(filename);
    if(!fontResource)
        return -1;
    FreeTypes::ftNewFaceFromReadable(fontResource, 0, &face);
    FreeTypes::ftSetCharSize(face, FreeTypes::ftF26Dot6(24, 0), 0, 96, 0);                 /* set character size */
    /* error handling omitted */

    slot = face->glyph;

    pen.x = 0;
    pen.y = 0;

    uint32_t lineHeight = 24 * 96 / 72;

    for(n = 0; n < num_chars; n++)
    {
        /* set transformation */
        FT_Set_Transform(face, nullptr, &pen);

        /* load glyph image into the slot (erase previous one) */
        error = FT_Load_Char(face, text[n], FT_LOAD_RENDER);
        if(error)
            continue;                 /* ignore errors */

        /* now, draw to our target surface (convert position) */
        draw_bitmap(&slot->bitmap,
                    slot->bitmap_left,
                    lineHeight - slot->bitmap_top);

        /* increment pen position */
        pen.x += slot->advance.x;
        pen.y += slot->advance.y;
    }

    GLDebug::glDumpBitmapToPngFile(image.get(), "ttf-fonts.png");

    FT_Done_Face(face);

    return 0;
}

namespace ark {
namespace unittest {

class TTFFontsTestCase : public TestCase {
public:
    virtual int launch() {
        std::string defaultFontFamily = Platform::getDefaultFontFamily();
        const char* args[] = {"test", defaultFontFamily.c_str(), "fopen"};
        return loadfonts(3, args);
    }
};

}
}

ark::unittest::TestCase* ttf_fonts_create()
{
    return new ark::unittest::TTFFontsTestCase();
}
