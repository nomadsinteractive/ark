#include "test/base/test_case.h"

#include "base/types/shared_ptr.h"
#include "base/impl/variable/variable_impl.h"
#include "base/util/math.h"
#include "base/util/values.h"

#include "graphics/base/render_object.h"
#include "graphics/base/transform.h"


namespace ark {
namespace unittest {

class RenderObjectTestCase : public TestCase {
public:
    virtual int launch() {
        sp<Transform> transform = sp<Transform>::adopt(new Transform());
        RenderObject renderObject(0, Values::null<Vertex>(), sp<Size>::make(1.0f, 1.0f), transform);
        renderObject.transform()->setRotate(sp<Numeric>::adopt(new VariableImpl<float>(Math::PI / 6)));
        const Quad& quad = renderObject.quad();
        if(quad.topLeft()->x() != 0 || quad.topLeft()->y() != 0)
            return -1;
        if(quad.bottomLeft()->x() != -0.5f)
            return -1;
        if(quad.topRight()->y() != 0.5f)
            return -1;
        return 0;
    }
};

}
}

ark::unittest::TestCase* render_objects_create() {
    return new ark::unittest::RenderObjectTestCase();
}
