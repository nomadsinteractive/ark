#include "base/types/shared_ptr.h"

#include "base/bean_factory.h"
#include "base/dom/document.h"
#include "base/inf/builder.h"
#include "base/types/null.h"
#include "base/util/values.h"

#include "test/base/test_case.h"

namespace ark {
namespace unittest {

namespace {

class BuilderImpl1 : public Builder<uint8_t>, public RefCount<BuilderImpl1> {
public:
    virtual sp<uint8_t> build(const document& doc, const WeakPtr<BeanFactory>& args) override {
        return sp<uint8_t>::make(1);
    }
};

class BuilderImpl2 : public Builder<uint16_t>, public RefCount<BuilderImpl2> {
public:
    virtual sp<uint16_t> build(const document& doc, const WeakPtr<BeanFactory>& args) override {
        return sp<uint16_t>::make(2);
    }
};

class BuilderImpl3 : public Builder<uint32_t>, public RefCount<BuilderImpl3> {
public:
    virtual sp<uint32_t> build(const document& doc, const WeakPtr<BeanFactory>& args) override {
        return sp<uint32_t>::make(3);
    }
};

class DictionaryImpl : public Dictionary<document> {
public:
    virtual const document get(const std::string& name, const WeakPtr<BeanFactory>& args) override {
        return document::make("name");
    }
};

class DictionaryImpl1 : public Dictionary<sp<uint8_t>> {
public:
    virtual const sp<uint8_t> get(const std::string& name, const WeakPtr<BeanFactory>& args) override {
        return sp<uint8_t>::make(static_cast<uint8_t>(Values::toFloat(args, name)));
    }
};

class DictionaryImpl2 : public Dictionary<sp<uint16_t>> {
public:
    virtual const sp<uint16_t> get(const std::string& name, const WeakPtr<BeanFactory>& args) override {
        return sp<uint16_t>::make(static_cast<uint16_t>(Values::toFloat(args, name)));
    }
};

class DictionaryImpl3 : public Dictionary<sp<uint32_t>> {
public:
    virtual const sp<uint32_t> get(const std::string& name, const WeakPtr<BeanFactory>& args) override {
        return sp<uint32_t>::make(static_cast<uint32_t>(Values::toFloat(args, name)));
    }
};

}

class BeanFactoriesTestCase : public TestCase {
public:
    virtual int launch() {
        {
            BeanFactory::Maker maker(sp<DictionaryImpl>::make());
            maker.addBuilder<uint8_t>(sp<BuilderImpl1>::make());
            maker.addBuilder<uint16_t>(sp<BuilderImpl2>::make());
            maker.addBuilder<uint32_t>(sp<BuilderImpl3>::make());
            maker.addDictionary<uint8_t>(sp<DictionaryImpl1>::make());
            maker.addDictionary<uint16_t>(sp<DictionaryImpl2>::make());
            maker.addDictionary<uint32_t>(sp<DictionaryImpl3>::make());
            sp<BeanFactory> beanFactory = sp<BeanFactory>::make();
            beanFactory->addWorker(maker.make());
            if((*beanFactory->load<uint8_t>("").get()) != 1)
                return 1;
            if((*beanFactory->load<uint16_t>("").get()) != 2)
                return 2;
            if((*beanFactory->load<uint32_t>("").get()) != 3)
                return 3;
            if((*beanFactory->build<uint8_t>("1").get()) != 1)
                return 4;
            if((*beanFactory->build<uint16_t>("2").get()) != 2)
                return 5;
            if((*beanFactory->build<uint32_t>("3").get()) != 3)
                return 6;
        }
        return BuilderImpl1::refCount() == 0 && BuilderImpl2::refCount() == 0 && BuilderImpl3::refCount() == 0 ? 0 : 4;
    }
};

}
}


ark::unittest::TestCase* bean_factories_create() {
    return new ark::unittest::BeanFactoriesTestCase();
}
