#include <vector>

#include "base/types/class.h"
#include "base/types/shared_ptr.h"
#include "base/types/weak_ptr.h"

#include "test/base/test_case.h"

class A {
public:
    virtual ~A() = default;
    int a = 1;
    int b = 2;
    int c = 3;
};

class B : public A, public ark::Class<B>::Implements<A> {
public:
    virtual ~B() = default;
    int d = 4;
    int e = 5;
    int f = 6;
};

class D {
public:
    virtual ~D() = default;
    int g = 7;
    int h = 8;
};

class E {
public:
    int i = 9;
};

class H {
public:
    virtual ~H() = default;

    int j = 10;
};

class I : public H {
public:
    int k = 11;
};

class Node final : public B, public D, public ark::Class<Node>::Implements<B, D> {
public:
    Node() {
    }

    Node(const Node& node) {
    }
};

template<typename... Args> class Interface {
public:
    template<typename T> bool is() {
        return check<T, Args...>();
    }

private:
    template<typename T> bool check() {
        return false;
    }

    template<typename T, typename U, typename... Types> bool check() {
        if(std::is_same<T, U>::value)
            return true;
        if(sizeof...(Types) == 0)
            return std::is_same<T, U>::value;
        return check<T, Types...>();
    }
};

namespace ark {
namespace unittest {

class TypesTestCase : public TestCase {
public:
    virtual int launch() {
        const sp<B> node = sp<Node>::make();
        if(!node.as<Node>() || !node.as<A>() || !node.as<D>())
            return 1;
        if(node.as<Node>()->a != 1 || node.as<Node>()->b != 2)
            return 2;
        if(node.as<A>()->a != 1 || node.as<A>()->b != 2)
            return 3;

        sp<A> a = node;
        if(!a.as<Node>() || !a.as<A>() || !a.as<D>())
            return 4;
        if(a.as<Node>()->a != 1 || a.as<Node>()->b != 2)
            return 5;
        if(a->a != 1 || a->b != 2)
            return 6;

        sp<E> e = sp<E>::make();
        a.absorb(e);
        if(!a.is<Node>() || !a.is<A>() || !a.is<D>())
            return 7;
        if(a.as<Node>()->a != 1 || a.as<Node>()->b != 2)
            return 8;
        if(a->a != 1 || a->b != 2)
            return 9;
        if(!e.is<E>())
            return 10;
        if(!a.is<E>() || a.as<E>()->i != 9)
            return 11;

        a.absorb<H>(sp<I>::make());
        if(!a.is<H>())
            return 12;

        sp<D> d = sp<D>::make();
        d.absorb(a);
        if(!d.is<D>() || d.as<D>()->g != 7)
            return 11;
        if(!d.is<Node>() || d.as<Node>()->h != 8)
            return 13;
        if(!d.is<E>() || d.as<E>()->i != 9)
            return 14;

        Class<Node> nodeClass = Class<Node>::instance();
        if(!nodeClass)
            return 15;

        std::set<TypeId> types = nodeClass.types();
        if(types.find(Type<B>::id()) == types.end())
            return 16;

        WeakPtr<B> parent = node;
        if(!parent || parent->a != 1)
            return 17;

        sp<Node> n1 = sp<Node>::adopt(new Node());
        const sp<B> castedB = nodeClass.cast<B>(n1);
        if(!castedB && castedB->d != 4)
            return 18;

        const sp<D> castedD = nodeClass.cast<D>(n1);
        if(!castedD && castedD->h != 8)
            return 19;

        Interface<uint8_t, uint16_t, uint32_t, uint64_t> interfaces;

        if(!interfaces.is<uint8_t>())
            return 20;

        if(!interfaces.is<uint16_t>() || !interfaces.is<uint32_t>() || !interfaces.is<uint64_t>())
            return 21;

        if(interfaces.is<void>())
            return 22;

        return 0;
    }
};

}
}


ark::unittest::TestCase* types_create() {
    return new ark::unittest::TypesTestCase();
}
